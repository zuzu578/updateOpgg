# updateOpgg
리그오브레전드 api 전적검색  리펙토링 
# 기능 추가 
<img width="927" alt="스크린샷 2021-10-02 오전 1 28 15" src="https://user-images.githubusercontent.com/69393030/135655520-5122cedb-88bb-4b68-b51b-56486d646862.png">
1) kda 
2) 아이템 이미지 
3) 승패여부 
4) v4 api 가 사라지고 v5 로 바뀌면서 바뀐 로직들을 다시 리펙토링하고 재 구현 함 
# jsp 
 <img width="986" alt="스크린샷 2021-10-02 오전 1 29 38" src="https://user-images.githubusercontent.com/69393030/135655695-37a19186-f240-4fab-a27f-b07b1b3377c4.png">
 
 # server 

<img width="986" alt="스크린샷 2021-10-02 오전 1 29 51" src="https://user-images.githubusercontent.com/69393030/135655719-14ebec65-981b-47aa-9c52-9a96761a2622.png">
